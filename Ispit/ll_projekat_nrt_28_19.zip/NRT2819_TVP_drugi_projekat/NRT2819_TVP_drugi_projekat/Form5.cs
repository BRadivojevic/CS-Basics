﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NRT2819_TVP_drugi_projekat
{
    public partial class Form5 : Form
    {
        List<Proizvod> proizvodi;
        int izabraniID = -1;
        public Form5()
        {
            InitializeComponent();
        }

        public void ucitajPodatke()
        {
            proizvodi = new List<Proizvod>();
            OleDbDataReader reader = Baza.getInstance().citajKomanda("SELECT * FROM Proizvod");
            while (reader.Read())
            {
                int broj = 0;
                Proizvod pr = new Proizvod();
                pr.ProizvodID = int.Parse(reader["ProizvodID"].ToString());
                pr.Naziv = reader["Naziv"].ToString();
                //JANUAR
                if (int.TryParse(reader["januar_prodato"].ToString(), out broj))
                {
                    pr.meseci.januar_prodato = broj;
                }
                else
                {
                    pr.meseci.januar_prodato = 0;
                }
                //FEBRUAR
                if (int.TryParse(reader["februar_prodato"].ToString(), out broj))
                {
                    pr.meseci.februar_prodato = broj;
                }
                else
                {
                    pr.meseci.februar_prodato = 0;
                }
                //MART
                if (int.TryParse(reader["mart_prodato"].ToString(), out broj))
                {
                    pr.meseci.mart_prodato = broj;
                }
                else
                {
                    pr.meseci.mart_prodato = 0;
                }
                //APRIL
                if (int.TryParse(reader["april_prodato"].ToString(), out broj))
                {
                    pr.meseci.april_prodato = broj;
                }
                else
                {
                    pr.meseci.april_prodato = 0;
                }
                //MAJ
                if (int.TryParse(reader["maj_prodato"].ToString(), out broj))
                {
                    pr.meseci.maj_prodato = broj;
                }
                else
                {
                    pr.meseci.maj_prodato = 0;
                }
                //JUN
                if (int.TryParse(reader["jun_prodato"].ToString(), out broj))
                {
                    pr.meseci.jun_prodato = broj;
                }
                else
                {
                    pr.meseci.jun_prodato = 0;
                }
                //JUL
                if (int.TryParse(reader["jul_prodato"].ToString(), out broj))
                {
                    pr.meseci.jul_prodato = broj;
                }
                else
                {
                    pr.meseci.jul_prodato = 0;
                }
                //AVGUST
                if (int.TryParse(reader["avgust_prodato"].ToString(), out broj))
                {
                    pr.meseci.avgust_prodato = broj;
                }
                else
                {
                    pr.meseci.avgust_prodato = 0;
                }
                //SEPTEMBAR
                if (int.TryParse(reader["septembar_prodato"].ToString(), out broj))
                {
                    pr.meseci.septembar_prodato = broj;
                }
                else
                {
                    pr.meseci.septembar_prodato = 0;
                }
                //OKTOBAR
                if (int.TryParse(reader["oktobar_prodato"].ToString(), out broj))
                {
                    pr.meseci.oktobar_prodato = broj;
                }
                else
                {
                    pr.meseci.oktobar_prodato = 0;
                }
                //NOVEMBAR
                if (int.TryParse(reader["novembar_prodato"].ToString(), out broj))
                {
                    pr.meseci.novembar_prodato = broj;
                }
                else
                {
                    pr.meseci.novembar_prodato = 0;
                }
                //DECEMBAR
                if (int.TryParse(reader["decembar_prodato"].ToString(), out broj))
                {
                    pr.meseci.decembar_prodato = broj;
                }
                else
                {
                    pr.meseci.decembar_prodato = 0;
                }

                proizvodi.Add(pr);
            }
            listBox1.DataSource = null;
            listBox1.DisplayMember = "naziv";
            listBox1.ValueMember = "proizvodid";
            listBox1.DataSource = proizvodi;

        }

        private void Form5_Load(object sender, EventArgs e)
        {
            ucitajPodatke();
        }

        public void statistika()
        {
            this.Refresh();
            izabraniID = listBox1.SelectedIndex + 1;
            int prodati = 0;
            int ostali_prod = 0;
            foreach (Proizvod p in proizvodi)
            {
                if (rb_Jan.Checked)
                {
                    if (p.ProizvodID == izabraniID + 1)
                    {
                        prodati = p.meseci.januar_prodato;
                    }
                    else
                    {
                        ostali_prod += p.meseci.januar_prodato;
                    }
                }

                if (rb_Feb.Checked)
                {
                    if (p.ProizvodID == izabraniID + 1)
                    {
                        prodati = p.meseci.februar_prodato;
                    }
                    else
                    {
                        ostali_prod += p.meseci.februar_prodato;
                    }
                }

                if (rb_Mrt.Checked)
                {
                    if (p.ProizvodID == izabraniID + 1)
                    {
                        prodati = p.meseci.mart_prodato;
                    }
                    else
                    {
                        ostali_prod += p.meseci.mart_prodato;
                    }
                }

                if (rb_Apr.Checked)
                {
                    if (p.ProizvodID == izabraniID + 1)
                    {
                        prodati = p.meseci.april_prodato;
                    }
                    else
                    {
                        ostali_prod += p.meseci.april_prodato;
                    }
                }

                if (rb_Maj.Checked)
                {
                    if (p.ProizvodID == izabraniID + 1)
                    {
                        prodati = p.meseci.maj_prodato;
                    }
                    else
                    {
                        ostali_prod += p.meseci.maj_prodato;
                    }
                }

                if (rb_Jun.Checked)
                {
                    if (p.ProizvodID == izabraniID + 1)
                    {
                        prodati = p.meseci.jun_prodato;
                    }
                    else
                    {
                        ostali_prod += p.meseci.jun_prodato;
                    }
                }

                if (rb_Jul.Checked)
                {
                    if (p.ProizvodID == izabraniID + 1)
                    {
                        prodati = p.meseci.jul_prodato;
                    }
                    else
                    {
                        ostali_prod += p.meseci.jul_prodato;
                    }
                }

                if (rb_Avg.Checked)
                {
                    if (p.ProizvodID == izabraniID + 1)
                    {
                        prodati = p.meseci.avgust_prodato;
                    }
                    else
                    {
                        ostali_prod += p.meseci.avgust_prodato;
                    }
                }

                if (rb_Spt.Checked)
                {
                    if (p.ProizvodID == izabraniID + 1)
                    {
                        prodati = p.meseci.septembar_prodato;
                    }
                    else
                    {
                        ostali_prod += p.meseci.septembar_prodato;
                    }
                }

                if (rb_Okt.Checked)
                {
                    if (p.ProizvodID == izabraniID + 1)
                    {
                        prodati = p.meseci.oktobar_prodato;
                    }
                    else
                    {
                        ostali_prod += p.meseci.oktobar_prodato;
                    }
                }

                if (rb_Nov.Checked)
                {
                    if (p.ProizvodID == izabraniID + 1)
                    {
                        prodati = p.meseci.novembar_prodato;
                    }
                    else
                    {
                        ostali_prod += p.meseci.novembar_prodato;
                    }
                }

                if (rb_Dec.Checked)
                {
                    if (p.ProizvodID == izabraniID + 1)
                    {
                        prodati = p.meseci.decembar_prodato;
                    }
                    else
                    {
                        ostali_prod += p.meseci.decembar_prodato;
                    }
                }
            }
            label3.Text = prodati.ToString();
            label4.Text = ostali_prod.ToString();

            Graphics g = this.CreateGraphics();
            int sum = prodati + ostali_prod;

            if (sum != 0)
            {
                double procenat_pom = ((double)ostali_prod / sum) * 100;
                int procenat1 = 100 - (int)Math.Round(procenat_pom);
                int procenat2 = 100 - procenat1;

                Rectangle pravougaonik = new Rectangle(326, 97, 150, 150);
                g.FillPie(Brushes.MediumSeaGreen, pravougaonik, 0, -((float)procenat2 / 100) * 360);
                g.FillPie(Brushes.DimGray, pravougaonik, 0, ((float)procenat2 / 100) * 360);
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            statistika();
        }

        private void rb_Jan_CheckedChanged(object sender, EventArgs e)
        {
            statistika();
        }

        private void rb_Feb_CheckedChanged(object sender, EventArgs e)
        {
            statistika();
        }

        private void rb_Mrt_CheckedChanged(object sender, EventArgs e)
        {
            statistika();
        }

        private void rb_Apr_CheckedChanged(object sender, EventArgs e)
        {
            statistika();
        }

        private void rb_Maj_CheckedChanged(object sender, EventArgs e)
        {
            statistika();
        }

        private void rb_Jun_CheckedChanged(object sender, EventArgs e)
        {
            statistika();
        }

        private void rb_Jul_CheckedChanged(object sender, EventArgs e)
        {
            statistika();
        }

        private void rb_Avg_CheckedChanged(object sender, EventArgs e)
        {
            statistika();
        }

        private void rb_Spt_CheckedChanged(object sender, EventArgs e)
        {
            statistika();
        }

        private void rb_Okt_CheckedChanged(object sender, EventArgs e)
        {
            statistika();
        }

        private void rb_Nov_CheckedChanged(object sender, EventArgs e)
        {
            statistika();
        }

        private void rb_Dec_CheckedChanged(object sender, EventArgs e)
        {
            statistika();
        }
    }
}
