﻿namespace NRT2819_TVP_drugi_projekat
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.rb_Jan = new System.Windows.Forms.RadioButton();
            this.rb_Feb = new System.Windows.Forms.RadioButton();
            this.rb_Mrt = new System.Windows.Forms.RadioButton();
            this.rb_Jun = new System.Windows.Forms.RadioButton();
            this.rb_Maj = new System.Windows.Forms.RadioButton();
            this.rb_Apr = new System.Windows.Forms.RadioButton();
            this.rb_Spt = new System.Windows.Forms.RadioButton();
            this.rb_Avg = new System.Windows.Forms.RadioButton();
            this.rb_Jul = new System.Windows.Forms.RadioButton();
            this.rb_Dec = new System.Windows.Forms.RadioButton();
            this.rb_Nov = new System.Windows.Forms.RadioButton();
            this.rb_Okt = new System.Windows.Forms.RadioButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 20;
            this.listBox1.Location = new System.Drawing.Point(0, 2);
            this.listBox1.Name = "listBox1";
            this.listBox1.ScrollAlwaysVisible = true;
            this.listBox1.Size = new System.Drawing.Size(170, 364);
            this.listBox1.TabIndex = 0;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // rb_Jan
            // 
            this.rb_Jan.AutoSize = true;
            this.rb_Jan.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.rb_Jan.Location = new System.Drawing.Point(175, 7);
            this.rb_Jan.Name = "rb_Jan";
            this.rb_Jan.Size = new System.Drawing.Size(76, 24);
            this.rb_Jan.TabIndex = 1;
            this.rb_Jan.TabStop = true;
            this.rb_Jan.Text = "Januar";
            this.rb_Jan.UseVisualStyleBackColor = true;
            this.rb_Jan.CheckedChanged += new System.EventHandler(this.rb_Jan_CheckedChanged);
            // 
            // rb_Feb
            // 
            this.rb_Feb.AutoSize = true;
            this.rb_Feb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.rb_Feb.Location = new System.Drawing.Point(175, 37);
            this.rb_Feb.Name = "rb_Feb";
            this.rb_Feb.Size = new System.Drawing.Size(83, 24);
            this.rb_Feb.TabIndex = 2;
            this.rb_Feb.TabStop = true;
            this.rb_Feb.Text = "Februar";
            this.rb_Feb.UseVisualStyleBackColor = true;
            this.rb_Feb.CheckedChanged += new System.EventHandler(this.rb_Feb_CheckedChanged);
            // 
            // rb_Mrt
            // 
            this.rb_Mrt.AutoSize = true;
            this.rb_Mrt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.rb_Mrt.Location = new System.Drawing.Point(175, 67);
            this.rb_Mrt.Name = "rb_Mrt";
            this.rb_Mrt.Size = new System.Drawing.Size(59, 24);
            this.rb_Mrt.TabIndex = 3;
            this.rb_Mrt.TabStop = true;
            this.rb_Mrt.Text = "Mart";
            this.rb_Mrt.UseVisualStyleBackColor = true;
            this.rb_Mrt.CheckedChanged += new System.EventHandler(this.rb_Mrt_CheckedChanged);
            // 
            // rb_Jun
            // 
            this.rb_Jun.AutoSize = true;
            this.rb_Jun.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.rb_Jun.Location = new System.Drawing.Point(175, 157);
            this.rb_Jun.Name = "rb_Jun";
            this.rb_Jun.Size = new System.Drawing.Size(53, 24);
            this.rb_Jun.TabIndex = 6;
            this.rb_Jun.TabStop = true;
            this.rb_Jun.Text = "Jun";
            this.rb_Jun.UseVisualStyleBackColor = true;
            this.rb_Jun.CheckedChanged += new System.EventHandler(this.rb_Jun_CheckedChanged);
            // 
            // rb_Maj
            // 
            this.rb_Maj.AutoSize = true;
            this.rb_Maj.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.rb_Maj.Location = new System.Drawing.Point(175, 127);
            this.rb_Maj.Name = "rb_Maj";
            this.rb_Maj.Size = new System.Drawing.Size(52, 24);
            this.rb_Maj.TabIndex = 5;
            this.rb_Maj.TabStop = true;
            this.rb_Maj.Text = "Maj";
            this.rb_Maj.UseVisualStyleBackColor = true;
            this.rb_Maj.CheckedChanged += new System.EventHandler(this.rb_Maj_CheckedChanged);
            // 
            // rb_Apr
            // 
            this.rb_Apr.AutoSize = true;
            this.rb_Apr.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.rb_Apr.Location = new System.Drawing.Point(175, 97);
            this.rb_Apr.Name = "rb_Apr";
            this.rb_Apr.Size = new System.Drawing.Size(58, 24);
            this.rb_Apr.TabIndex = 4;
            this.rb_Apr.TabStop = true;
            this.rb_Apr.Text = "April";
            this.rb_Apr.UseVisualStyleBackColor = true;
            this.rb_Apr.CheckedChanged += new System.EventHandler(this.rb_Apr_CheckedChanged);
            // 
            // rb_Spt
            // 
            this.rb_Spt.AutoSize = true;
            this.rb_Spt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.rb_Spt.Location = new System.Drawing.Point(175, 247);
            this.rb_Spt.Name = "rb_Spt";
            this.rb_Spt.Size = new System.Drawing.Size(106, 24);
            this.rb_Spt.TabIndex = 9;
            this.rb_Spt.TabStop = true;
            this.rb_Spt.Text = "Septembar";
            this.rb_Spt.UseVisualStyleBackColor = true;
            this.rb_Spt.CheckedChanged += new System.EventHandler(this.rb_Spt_CheckedChanged);
            // 
            // rb_Avg
            // 
            this.rb_Avg.AutoSize = true;
            this.rb_Avg.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.rb_Avg.Location = new System.Drawing.Point(175, 217);
            this.rb_Avg.Name = "rb_Avg";
            this.rb_Avg.Size = new System.Drawing.Size(76, 24);
            this.rb_Avg.TabIndex = 8;
            this.rb_Avg.TabStop = true;
            this.rb_Avg.Text = "Avgust";
            this.rb_Avg.UseVisualStyleBackColor = true;
            this.rb_Avg.CheckedChanged += new System.EventHandler(this.rb_Avg_CheckedChanged);
            // 
            // rb_Jul
            // 
            this.rb_Jul.AutoSize = true;
            this.rb_Jul.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.rb_Jul.Location = new System.Drawing.Point(175, 187);
            this.rb_Jul.Name = "rb_Jul";
            this.rb_Jul.Size = new System.Drawing.Size(47, 24);
            this.rb_Jul.TabIndex = 7;
            this.rb_Jul.TabStop = true;
            this.rb_Jul.Text = "Jul";
            this.rb_Jul.UseVisualStyleBackColor = true;
            this.rb_Jul.CheckedChanged += new System.EventHandler(this.rb_Jul_CheckedChanged);
            // 
            // rb_Dec
            // 
            this.rb_Dec.AutoSize = true;
            this.rb_Dec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.rb_Dec.Location = new System.Drawing.Point(175, 337);
            this.rb_Dec.Name = "rb_Dec";
            this.rb_Dec.Size = new System.Drawing.Size(101, 24);
            this.rb_Dec.TabIndex = 12;
            this.rb_Dec.TabStop = true;
            this.rb_Dec.Text = "Decembar";
            this.rb_Dec.UseVisualStyleBackColor = true;
            this.rb_Dec.CheckedChanged += new System.EventHandler(this.rb_Dec_CheckedChanged);
            // 
            // rb_Nov
            // 
            this.rb_Nov.AutoSize = true;
            this.rb_Nov.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.rb_Nov.Location = new System.Drawing.Point(175, 307);
            this.rb_Nov.Name = "rb_Nov";
            this.rb_Nov.Size = new System.Drawing.Size(99, 24);
            this.rb_Nov.TabIndex = 11;
            this.rb_Nov.TabStop = true;
            this.rb_Nov.Text = "Novembar";
            this.rb_Nov.UseVisualStyleBackColor = true;
            this.rb_Nov.CheckedChanged += new System.EventHandler(this.rb_Nov_CheckedChanged);
            // 
            // rb_Okt
            // 
            this.rb_Okt.AutoSize = true;
            this.rb_Okt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.rb_Okt.Location = new System.Drawing.Point(175, 277);
            this.rb_Okt.Name = "rb_Okt";
            this.rb_Okt.Size = new System.Drawing.Size(84, 24);
            this.rb_Okt.TabIndex = 10;
            this.rb_Okt.TabStop = true;
            this.rb_Okt.Text = "Oktobar";
            this.rb_Okt.UseVisualStyleBackColor = true;
            this.rb_Okt.CheckedChanged += new System.EventHandler(this.rb_Okt_CheckedChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.pictureBox1.Location = new System.Drawing.Point(281, -2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(10, 371);
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(339, 251);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 20);
            this.label1.TabIndex = 14;
            this.label1.Text = "Izabrano:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(418, 251);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 20);
            this.label2.TabIndex = 15;
            this.label2.Text = "Ostalo:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(338, 279);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(18, 20);
            this.label3.TabIndex = 16;
            this.label3.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(417, 279);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(18, 20);
            this.label4.TabIndex = 17;
            this.label4.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(326, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(365, 20);
            this.label5.TabIndex = 18;
            this.label5.Text = "Statisticki prikaz izabranih proizvoda po mesecima:";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox2.Location = new System.Drawing.Point(572, 157);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(21, 21);
            this.pictureBox2.TabIndex = 19;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.pictureBox3.Location = new System.Drawing.Point(572, 127);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(21, 21);
            this.pictureBox3.TabIndex = 20;
            this.pictureBox3.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.Control;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.ForeColor = System.Drawing.Color.MediumSeaGreen;
            this.label6.Location = new System.Drawing.Point(599, 128);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 20);
            this.label6.TabIndex = 21;
            this.label6.Text = "Izabrano";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.ForeColor = System.Drawing.Color.DimGray;
            this.label7.Location = new System.Drawing.Point(599, 158);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 20);
            this.label7.TabIndex = 22;
            this.label7.Text = "Ostalo";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label8.Location = new System.Drawing.Point(359, 71);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 20);
            this.label8.TabIndex = 23;
            this.label8.Text = "Izabrano:";
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(712, 366);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.rb_Dec);
            this.Controls.Add(this.rb_Nov);
            this.Controls.Add(this.rb_Okt);
            this.Controls.Add(this.rb_Spt);
            this.Controls.Add(this.rb_Avg);
            this.Controls.Add(this.rb_Jul);
            this.Controls.Add(this.rb_Jun);
            this.Controls.Add(this.rb_Maj);
            this.Controls.Add(this.rb_Apr);
            this.Controls.Add(this.rb_Mrt);
            this.Controls.Add(this.rb_Feb);
            this.Controls.Add(this.rb_Jan);
            this.Controls.Add(this.listBox1);
            this.Name = "Form5";
            this.Text = "Statistika";
            this.Load += new System.EventHandler(this.Form5_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.RadioButton rb_Jan;
        private System.Windows.Forms.RadioButton rb_Feb;
        private System.Windows.Forms.RadioButton rb_Mrt;
        private System.Windows.Forms.RadioButton rb_Jun;
        private System.Windows.Forms.RadioButton rb_Maj;
        private System.Windows.Forms.RadioButton rb_Apr;
        private System.Windows.Forms.RadioButton rb_Spt;
        private System.Windows.Forms.RadioButton rb_Avg;
        private System.Windows.Forms.RadioButton rb_Jul;
        private System.Windows.Forms.RadioButton rb_Dec;
        private System.Windows.Forms.RadioButton rb_Nov;
        private System.Windows.Forms.RadioButton rb_Okt;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
    }
}