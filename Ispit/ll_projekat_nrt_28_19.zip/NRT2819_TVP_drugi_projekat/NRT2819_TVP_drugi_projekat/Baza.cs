﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NRT2819_TVP_drugi_projekat
{
    class Baza
    {
        private OleDbConnection konekcija;
        private static Baza baza;

        private Baza()
        {
            konekcija = new OleDbConnection();
            konekcija.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Stefan\source\repos\NRT2819_TVP_drugi_projekat\prodavnica.accdb";
            konekcija.Open();
        }

        public static Baza getInstance()
        {
            if(baza == null)
            {
                baza = new Baza();
            }

            return baza;
        }

        public OleDbDataReader citajKomanda(String komanda)
        {
            OleDbCommand cmd = new OleDbCommand();
            cmd.Connection = konekcija;
            cmd.CommandText = komanda;
            return cmd.ExecuteReader();
        }

        public void upisiKomanda(String komanda)
        {
            OleDbCommand cmd = new OleDbCommand();
            cmd.Connection = konekcija;
            cmd.CommandText = komanda;
            cmd.ExecuteNonQuery();
        }

        public void zatvoriKonekciju()
        {
            if (konekcija != null)
                konekcija.Close();
        }
    }
}
