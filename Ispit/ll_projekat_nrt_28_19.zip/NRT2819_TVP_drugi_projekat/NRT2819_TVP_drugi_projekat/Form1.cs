﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NRT2819_TVP_drugi_projekat
{    enum meseciE
    {
        januar, februar, mart, april, maj, jun, jul, avgust, septembar, oktobar, novembar, decembar
    }
    public partial class Form1 : Form
    {
        List<Proizvod> proizvodi;
        List<Kategorija> kategorije;
        List<Proizvod> korpa;
        List<Proizvod> pretraga_pom;
        List<Proizvod> kolicine;
        int racun;

        public Form1()
        {
            InitializeComponent();
            proizvodi = new List<Proizvod>();
            kategorije = new List<Kategorija>();
            korpa = new List<Proizvod>();
            kolicine = new List<Proizvod>();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            korpa.Clear();
            try
            {
                OleDbDataReader reader = Baza.getInstance().citajKomanda("SELECT * FROM Kategorija");

                kategorije.Clear();
                while (reader.Read())
                {
                    Kategorija k = new Kategorija();

                    k.KategorijaID = int.Parse(reader["KategorijaID"].ToString());
                    k.Naziv = reader["Naziv"].ToString();

                    kategorije.Add(k);
                }

                comboBox1.DataSource = null;
                comboBox1.DisplayMember = "naziv";
                comboBox1.ValueMember = "kategorijaid";
                comboBox1.DataSource = kategorije;
            }
            catch(Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                OleDbDataReader reader = Baza.getInstance()
                    .citajKomanda($"SELECT * FROM Proizvod WHERE KategorijaID = {comboBox1.SelectedIndex + 1}");

                proizvodi.Clear();

                while (reader.Read())
                {
                    Proizvod p = new Proizvod();

                    p.ProizvodID = int.Parse(reader["ProizvodID"].ToString());
                    p.Naziv = reader["Naziv"].ToString();
                    p.Cena = int.Parse(reader["Cena"].ToString());
                    p.KategorijaID = int.Parse(reader["KategorijaID"].ToString());

                    proizvodi.Add(p);
                }
                //Sortiranje proizvoda po abecedi
                proizvodi.Sort(((x, y) => string.Compare(x.Naziv, y.Naziv)));

                //Formatiran combobox2 (Proizvodi)
                comboBox2.DataSource = null;
                comboBox2.DisplayMember = "naziv cena";
                comboBox2.ValueMember = "proizvodid";
                comboBox2.DataSource = proizvodi;
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        private void btnDodaj1_Click(object sender, EventArgs e)
        {
            int brojNumeric = (int)numericUpDown1.Value;
            racun = 0;

            //osvezavanje listbox-a
            lbKorpa.DataSource = null;

            //dodaje u korpu onoliko koliko je izabrano u numUpDown
            for(int i = 0; i < brojNumeric; i++)
            {
                korpa.Add(proizvodi[comboBox2.SelectedIndex]);
            }
            lbKorpa.DataSource = korpa;

            //izracunata ukupna cena za sve u korpi
            for (int i = 0; i < korpa.Count(); i++)
            {
                racun += korpa[i].Cena;
            }

            //prikaz cene
            lblCena.Text = racun.ToString() + "RSD";

            //vrati numUpDown na 1
            numericUpDown1.Value = 1;
        }

        
        private void txtPretraga_TextChanged(object sender, EventArgs e)
        {
            List<Proizvod> pretraga = new List<Proizvod>();
            pretraga_pom = new List<Proizvod>();
            int kategorijaID_Pom = -1;
            

            if (rbKategorija.Checked)
            {
                //unosenje u listu proizvoda
                try
                {
                    OleDbDataReader reader_proizvodi = Baza.getInstance().citajKomanda($"SELECT * FROM Proizvod");

                    proizvodi.Clear();

                    while (reader_proizvodi.Read())
                    {
                        Proizvod pom = new Proizvod();

                        pom.ProizvodID = int.Parse(reader_proizvodi["ProizvodID"].ToString());
                        pom.Naziv = reader_proizvodi["Naziv"].ToString();
                        pom.Cena = int.Parse(reader_proizvodi["Cena"].ToString());
                        pom.KategorijaID = int.Parse(reader_proizvodi["KategorijaID"].ToString());

                        pretraga.Add(pom);
                    }

                    pretraga.Sort(((x, y) => string.Compare(x.Naziv, y.Naziv)));
                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message);
                }
         

                //Unosenje u listu kategorija
                try
                {
         
                    OleDbDataReader reader_kategorije = Baza.getInstance().citajKomanda($"SELECT * FROM Kategorija");

                    kategorije.Clear();

                    while (reader_kategorije.Read())
                    {
                        Kategorija pom = new Kategorija();

                        pom.KategorijaID = int.Parse(reader_kategorije["KategorijaID"].ToString());
                        pom.Naziv = reader_kategorije["Naziv"].ToString();

                        kategorije.Add(pom);
                    }

                    kategorije.Sort(((x, y) => string.Compare(x.Naziv, y.Naziv)));

                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message);
                }
       

                foreach (Kategorija x in kategorije)
                {
                    if (x.Naziv.ToLower().StartsWith(txtPretraga.Text.ToLower()))
                    {
                        kategorijaID_Pom = x.KategorijaID;
                    }
                }
                foreach (Proizvod x in pretraga)
                {
                    if (x.KategorijaID == kategorijaID_Pom)
                    {
                        pretraga_pom.Add(x);
                    }
                }
            }

            if (rbNaziv.Checked)
            {
                try
                { 
                    OleDbDataReader reader_proizvodi = Baza.getInstance().citajKomanda($"SELECT * FROM Proizvod");

                    while (reader_proizvodi.Read())
                    {
                        Proizvod pom = new Proizvod();

                        pom.ProizvodID = int.Parse(reader_proizvodi["ProizvodID"].ToString());
                        pom.Naziv = reader_proizvodi["Naziv"].ToString();
                        pom.Cena = int.Parse(reader_proizvodi["Cena"].ToString());
                        pom.KategorijaID = int.Parse(reader_proizvodi["KategorijaID"].ToString());

                        pretraga.Add(pom);
                    }

                    pretraga.Sort(((x, y) => string.Compare(x.Naziv, y.Naziv)));

                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message);
                }
       

                foreach (Proizvod x in pretraga)
                {
                    if (x.Naziv.ToLower().StartsWith(txtPretraga.Text.ToLower()))
                    {
                        pretraga_pom.Add(x);
                    }
                }
            }

            if (txtPretraga.Text == "")
            {
                lbPretraga.DataSource = null;
            }
            else
                lbPretraga.DataSource = pretraga_pom;

        }

        private void btnDodaj2_Click(object sender, EventArgs e)
        {
            if (lbPretraga.Items.Count > 0)
            {
                int kolicina = (int)numericUpDown2.Value;
                racun = 0;

                lbKorpa.DataSource = null;

                for (int i = 0; i < kolicina; i++)
                {
                    korpa.Add(pretraga_pom[lbPretraga.SelectedIndex]);
                }

                lbKorpa.DataSource = korpa;

                for (int i = 0; i < korpa.Count(); i++)
                {
                    racun += korpa[i].Cena;
                }

                lblCena.Text = racun.ToString() + "RSD";
                numericUpDown2.Value = 1;
            }
            else
            {
                MessageBox.Show("Nista nije izabrano");
            }
        }

        private void btnKasa_Click(object sender, EventArgs e)
        {
            if (korpa.Count() == 0)
            {
                MessageBox.Show("Niste popunili korpu");
            }
            else
            {
                Form2 form_kasa = new Form2(korpa, lbKorpa, lblCena, kolicine);
                form_kasa.Show();
                lbKorpa.DataSource = null;
                lblCena.Text = "0RSD";
            }
        }

        private void btnDodajUBazu_Click(object sender, EventArgs e)
        {
            Form3 forma_dodaj = new Form3();
            forma_dodaj.Show();
        }

        
        private void btnRacun_Click(object sender, EventArgs e)
        {
            Form4 form_Racun = new Form4();
            form_Racun.Show();
        }

        private void btnStatistika_Click(object sender, EventArgs e)
        {
            Form5 form_statistika = new Form5();
            form_statistika.Show();
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Baza.getInstance().zatvoriKonekciju();
        }
    }
}
