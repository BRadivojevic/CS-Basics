﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NRT2819_TVP_drugi_projekat
{
    public partial class Form3 : Form
    {
        Baza baza;
        List<Kategorija> kategorije;
        List<Proizvod> proizvodi;
      
        public Form3()
        {
            baza = Baza.getInstance();
            kategorije = new List<Kategorija>();
            proizvodi = new List<Proizvod>();
            InitializeComponent();
            
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            
            try
            {
                OleDbDataReader citac = Baza.getInstance().citajKomanda("SELECT * FROM Kategorija");

                kategorije.Clear();
                while (citac.Read())
                {
                    Kategorija k = new Kategorija();
                    k.KategorijaID = int.Parse(citac["KategorijaID"].ToString());
                    k.Naziv = citac["Naziv"].ToString();
                    kategorije.Add(k);
                }

                cbKategorija.DataSource = null;
                cbKategorija.DisplayMember = "naziv";
                cbKategorija.ValueMember = "kategorijaid";
                cbKategorija.DataSource = kategorije;

            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
   
        }

        private void btnDodajUBazu_Click(object sender, EventArgs e)
        {
          
            if (tbNaziv.Text == "")
            {
                MessageBox.Show("Niste uneli naziv proizvoda");
            }
            else if (numCena.Value < 5)
            {
                MessageBox.Show("Cena proizvoda ne sme biti manja od 5 RSD");
            }
            else
            {
                //Dodavanje proizvoda
                int br_proizvoda = 0;                      
                OleDbDataReader reader = Baza.getInstance().citajKomanda("SELECT * FROM Proizvod");

                while (reader.Read())
                {
                    Proizvod p = new Proizvod();

                    p.ProizvodID = int.Parse(reader["ProizvodID"].ToString());
                    p.Naziv = reader["Naziv"].ToString();
                    p.Cena = int.Parse(reader["Cena"].ToString());
                    p.KategorijaID = int.Parse(reader["KategorijaID"].ToString());

                    proizvodi.Add(p);
                }

                if (proizvodi.Count() == 0)
                {
                    br_proizvoda = 1;
                }
                else
                {
                    br_proizvoda = proizvodi.Count() + 2;
                }
              

                Proizvod provera = new Proizvod(br_proizvoda, tbNaziv.Text, Convert.ToInt32(Math.Round(numCena.Value, 0)), cbKategorija.SelectedIndex + 1);

                bool ne_postoji = false;
                foreach (Proizvod p in proizvodi)
                {
                    if (p.Naziv.ToLower() == provera.Naziv.ToLower() && p.Cena == provera.Cena)
                    {
                        ne_postoji = false;
                        break;
                    }
                    else ne_postoji = true;
                }

                if (ne_postoji)
                {
                    Baza.getInstance().upisiKomanda($"INSERT INTO Proizvod (proizvodID, Naziv, Cena, KategorijaID) values({br_proizvoda}, '{tbNaziv.Text}', {numCena.Value}, {cbKategorija.SelectedIndex + 1})");                 
                    MessageBox.Show("Proizvod uspesno dodat u bazu");

                    this.Close();
                }
                else
                {
                    MessageBox.Show("Proizvod vec postoji u bazi");
                }


            }
        }
    }
}
