﻿namespace NRT2819_TVP_drugi_projekat
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.btnProdaj = new System.Windows.Forms.Button();
            this.btnStorniraj = new System.Windows.Forms.Button();
            this.btnUkloni = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblcena2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 20;
            this.listBox1.Location = new System.Drawing.Point(12, 12);
            this.listBox1.Name = "listBox1";
            this.listBox1.ScrollAlwaysVisible = true;
            this.listBox1.Size = new System.Drawing.Size(203, 204);
            this.listBox1.TabIndex = 0;
            // 
            // btnProdaj
            // 
            this.btnProdaj.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnProdaj.Location = new System.Drawing.Point(12, 222);
            this.btnProdaj.Name = "btnProdaj";
            this.btnProdaj.Size = new System.Drawing.Size(309, 72);
            this.btnProdaj.TabIndex = 1;
            this.btnProdaj.Text = "Prodaj";
            this.btnProdaj.UseVisualStyleBackColor = true;
            this.btnProdaj.Click += new System.EventHandler(this.btnProdaj_Click);
            // 
            // btnStorniraj
            // 
            this.btnStorniraj.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnStorniraj.Location = new System.Drawing.Point(221, 116);
            this.btnStorniraj.Name = "btnStorniraj";
            this.btnStorniraj.Size = new System.Drawing.Size(100, 100);
            this.btnStorniraj.TabIndex = 2;
            this.btnStorniraj.Text = "Storniraj racun";
            this.btnStorniraj.UseVisualStyleBackColor = true;
            this.btnStorniraj.Click += new System.EventHandler(this.btnStorniraj_Click);
            // 
            // btnUkloni
            // 
            this.btnUkloni.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnUkloni.Location = new System.Drawing.Point(221, 12);
            this.btnUkloni.Name = "btnUkloni";
            this.btnUkloni.Size = new System.Drawing.Size(100, 100);
            this.btnUkloni.TabIndex = 3;
            this.btnUkloni.Text = "Ukloni proizvod";
            this.btnUkloni.UseVisualStyleBackColor = true;
            this.btnUkloni.Click += new System.EventHandler(this.btnUkloni_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(73, 317);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 31);
            this.label1.TabIndex = 4;
            this.label1.Text = "Racun:";
            // 
            // lblcena2
            // 
            this.lblcena2.AutoSize = true;
            this.lblcena2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblcena2.Location = new System.Drawing.Point(166, 317);
            this.lblcena2.Name = "lblcena2";
            this.lblcena2.Size = new System.Drawing.Size(94, 31);
            this.lblcena2.TabIndex = 5;
            this.lblcena2.Text = "0 RSD";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(327, 369);
            this.ControlBox = false;
            this.Controls.Add(this.lblcena2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnUkloni);
            this.Controls.Add(this.btnStorniraj);
            this.Controls.Add(this.btnProdaj);
            this.Controls.Add(this.listBox1);
            this.Name = "Form2";
            this.Text = "Kasa";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button btnProdaj;
        private System.Windows.Forms.Button btnStorniraj;
        private System.Windows.Forms.Button btnUkloni;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblcena2;
    }
}