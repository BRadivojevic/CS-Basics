﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NRT2819_TVP_drugi_projekat
{
    public partial class Form4 : Form
    {
        List<Racun> racuni;
        public Form4()
        {
            InitializeComponent();
        }

        public void PrikaziRacune()
        {
            racuni = new List<Racun>();
            OleDbDataReader reader = Baza.getInstance().citajKomanda("SELECT * FROM Racun");

            while (reader.Read())
            {
                Racun racun = new Racun();

                racun.RacunID = int.Parse(reader["RacunID"].ToString());
                racun.Cena = int.Parse(reader["Cena"].ToString());
                racun.Vreme = Convert.ToDateTime(reader["Vreme"]);
                racuni.Add(racun);
            }
            string id = "";
            string cene = "";
            string vremena = "";

            foreach (Racun r in racuni)
            {
                id += r.RacunID + "- - - - - - - - - - - -" + Environment.NewLine;
                cene += r.Cena + "- - - - - - - - - - - -" + Environment.NewLine;
                vremena += r.Vreme + Environment.NewLine;
            }
            lbl_Id.Text = id;
            lbl_Cena.Text = cene;
            lbl_Vreme.Text = vremena;
            this.Height = 180 + lbl_Cena.Height;
        }


        private void lbl_Id_VisibleChanged(object sender, EventArgs e)
        {
            this.CenterToScreen();
            PrikaziRacune();
        }
    }
}
