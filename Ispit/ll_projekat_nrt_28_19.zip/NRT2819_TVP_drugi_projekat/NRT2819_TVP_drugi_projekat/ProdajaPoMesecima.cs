﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NRT2819_TVP_drugi_projekat
{
    public struct ProdajaPoMesecima
    {
        public int januar_prodato;
        public int februar_prodato;
        public int mart_prodato;
        public int april_prodato;
        public int maj_prodato;
        public int jun_prodato;
        public int jul_prodato;
        public int avgust_prodato;
        public int septembar_prodato;
        public int oktobar_prodato;
        public int novembar_prodato;
        public int decembar_prodato;
    }
}
