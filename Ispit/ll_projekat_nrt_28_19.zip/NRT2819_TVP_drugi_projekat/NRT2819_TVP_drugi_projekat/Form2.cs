﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NRT2819_TVP_drugi_projekat
{
    public partial class Form2 : Form
    {
        List<Proizvod> korpa;
        List<Racun> racuni;
        ListBox lb1;
        Label form1_cena;
        int racun = 0;

        
        public Form2(List<Proizvod> korpa, ListBox lb1, Label form1_cena, List<Proizvod> kolicine)
        {
            this.korpa = korpa;
            this.lb1 = lb1;
            this.form1_cena = form1_cena;
            InitializeComponent();

            this.CenterToScreen();
            izracunajCenu();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            listBox1.DataSource = korpa;
        }
        private void izracunajCenu()
        {
            racun = 0;
            foreach (Proizvod p in korpa)
            {
                racun += p.Cena;
            }

            lblcena2.Text = racun + "RSD";
        }

        private void btnUkloni_Click(object sender, EventArgs e)
        {
            if (korpa == null)
                MessageBox.Show("Nema vise elemenata");
            else
            {
                korpa.RemoveAt(listBox1.SelectedIndex);

                listBox1.DataSource = null;
                listBox1.DataSource = korpa;

                izracunajCenu();
            }

        }

        private void btnStorniraj_Click(object sender, EventArgs e)
        {
            string poruka = "Da li ste sigurni da zelite da obrisete racun?";
            if (MessageBox.Show(poruka, "UPOZORENJE", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                korpa.Clear();
                MessageBox.Show("Racun uspesno storniran");
                form1_cena.Text = "0RSD";
                this.Close();
            }
            else
            {
                MessageBox.Show("Storniranje prekinuto");
            }
        }
        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            lb1.DataSource = null;
        }

        private void btnProdaj_Click(object sender, EventArgs e)
        {
            int racunID = -1;
            racuni = new List<Racun>();

            //Citanje racuna
            OleDbDataReader reader = Baza.getInstance().citajKomanda("SELECT * FROM Racun");

            while (reader.Read())
            {
                Racun r = new Racun();

                r.RacunID = int.Parse(reader["RacunID"].ToString());
                r.Cena = int.Parse(reader["Cena"].ToString());
                r.Vreme = DateTime.Parse(reader["Vreme"].ToString());

                racuni.Add(r);
            }

            if (racuni.Count() == 0)
            {
                racunID = 1;
            }
            else
            {
                racunID = racuni.Count() + 1;
            }

            //Ubacivanje racuna u bazu
            Baza.getInstance().upisiKomanda($"INSERT INTO Racun (RacunID, Cena, Vreme) values({racunID}, {racun}, Now())");

            
            MessageBox.Show("Uspesna prodaja !");
            korpa.Clear();
            this.Close();
        }
    }
}
