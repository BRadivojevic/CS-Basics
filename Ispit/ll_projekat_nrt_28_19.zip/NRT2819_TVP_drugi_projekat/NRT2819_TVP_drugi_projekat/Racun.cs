﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NRT2819_TVP_drugi_projekat
{
    public class Racun
    {
        private int racunID;
        private int cena;
        private DateTime vreme;

        public int RacunID { get => racunID; set => racunID = value; }
        public int Cena { get => cena; set => cena = value; }
        public DateTime Vreme { get => vreme; set => vreme = value; }

        public Racun(int racunID, int cena, DateTime vreme)
        {
            this.RacunID = racunID;
            this.Cena = cena;
            this.Vreme = vreme;
        }
        public Racun()
        {
            this.RacunID = 0;
            this.Cena = 0;
            this.Vreme = DateTime.MinValue;
        }
    }
}
