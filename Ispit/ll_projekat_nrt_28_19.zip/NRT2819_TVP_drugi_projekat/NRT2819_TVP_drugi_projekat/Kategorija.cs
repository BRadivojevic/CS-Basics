﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NRT2819_TVP_drugi_projekat
{
    class Kategorija
    {
        private int kategorijaID;
        private string naziv;

        public int KategorijaID { get => kategorijaID; set => kategorijaID = value; }
        public string Naziv { get => naziv; set => naziv = value; }

        public Kategorija(int kategorijaID, string naziv)
        {
            this.KategorijaID = kategorijaID;
            this.Naziv = naziv;
        }
        public Kategorija()
        {
            this.KategorijaID = -1;
            this.Naziv = "";
        }
        public override string ToString()
        {
            return this.KategorijaID + " " + this.Naziv;
        }
    }
}
