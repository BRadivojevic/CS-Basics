﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NRT2819_TVP_drugi_projekat
{
    public class Proizvod
    {
        private int proizvodID;
        private string naziv;
        private int cena;
        private int kategorijaID;
        public ProdajaPoMesecima meseci;
        public int u_korpi;

        public int ProizvodID { get => proizvodID; set => proizvodID = value; }
        public string Naziv { get => naziv; set => naziv = value; }
        public int Cena { get => cena; set => cena = value; }
        public int KategorijaID { get => kategorijaID; set => kategorijaID = value; }

        public Proizvod(int proizvodID, string naziv, int cena, int kategorijaID)
        {
            this.ProizvodID = proizvodID;
            this.Naziv = naziv;
            this.Cena = cena;
            this.KategorijaID = kategorijaID;
        }
        public Proizvod()
        {
            this.ProizvodID = -1;
            this.Naziv = "";
            this.Cena = 0;
            this.KategorijaID = -1;
        }
        public override string ToString()
        {
            return this.naziv + " " + this.cena + " ";
        }
    }
}
